function changeHeading() {
    let heading = document.getElementById("heading");
    heading.style = "color: white; background-color: black";
}

function enlarge(){
    let image = document.getElementById("image");
    image.style = "width:200px;"
}

function minimise() {
    let image = document.getElementById("image");
    image.style = "width:100px"
}

function moveTopLeft() {
    let box = document.getElementById("box");
    box.style = "top: 0px; left: 0px;";
}

function moveTopRight() {
    let box = document.getElementById("box");
    box.style = "top: 0px; left: 100px;";
}

function moveBottomLeft() {
    let box = document.getElementById("box");
    box.style = "top: 100px; left: 0px;";
}

function moveBottomRight() {
    let box = document.getElementById("box");
    box.style = "top: 100px; left: 100px;";
}

function moveCentre() {
    let box = document.getElementById("box");
    box.style = "top: 50px; left: 50px;";
}
function slideDown() {
    let slider = document.getElementById("slider");
    slider.style = "top: 175px;";
}

function slideUp() {
    let slider = document.getElementById("slider");
    slider.style = "top: 0px;";
}