# CI - transition and movement CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/m0wneeek/pen/Rwzxzay](https://codepen.io/m0wneeek/pen/Rwzxzay).

